# Zupet.de Theme — CI-Ready Repo

Dieses Repo enthält **dein Theme** (Basis: *zupet*) sowie eine **GitHub Action**, die bei jedem Push automatisch den Auto-Patcher ausführt. 
Über die **Shopify GitHub Integration** wird jeder Commit **automatisch** ins verknüpfte Theme deployed.

## Schnellstart
1. Neues GitHub-Repo erstellen (leer), dann **diesen Ordner pushen**.
2. Im Shopify Admin: **Onlineshop → Themes → Add theme → Connect from GitHub** → Repo & Branch (z. B. `main`) auswählen.
3. Ab jetzt: **push → autopatch → auto-deploy**.

## Lokal testen
```bash
python tools/patch_zupet.py --theme-dir .
# Änderungen prüfen und committen:
git add -A && git commit -m "test: autopatch" && git push
```

## Dateien
- `.github/workflows/autopatch-and-commit.yml` – führt Auto-Patcher aus & commitet Änderungen.
- `tools/patch_zupet.py` – Patcher (Preconnect, Defer JS, JSON-LD Snippets + Render).
- `snippets/` – wird vom Script ergänzt, falls Snippets fehlen.

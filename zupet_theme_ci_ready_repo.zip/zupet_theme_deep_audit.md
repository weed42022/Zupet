# Zupet.de Theme Deep Audit (Base: zupet)

## Templates Overview

- `templates/404.json` — sections: 2 (order: 2) | types: featured-collection, main-404 | has `main-*`: True
- `templates/article.json` — sections: 2 (order: 2) | types: article-template, blog-posts | has `main-*`: False
- `templates/blog.json` — sections: 2 (order: 2) | types: blog-template, featured-collections | has `main-*`: False
- `templates/cart.json` — sections: 2 (order: 2) | types: featured-collection, main-cart | has `main-*`: True
- `templates/collection.collection-landing.json` — sections: 6 (order: 6) | types: featured-collection, featured-collections, main-collection, slideshow | has `main-*`: True
- `templates/collection.json` — sections: 1 (order: 1) | types: main-collection | has `main-*`: True
- `templates/index.json` — sections: 11 (order: 11) | types: collection-callout, faq, featured-collection, featured-collection-switcher, newsletter, rich-text, slideshow, testimonials, text-and-image, text-columns ... | has `main-*`: False
- `templates/list-collections.json` — sections: 1 (order: 1) | types: list-collections-template | has `main-*`: False
- `templates/page.about.json` — sections: 7 (order: 7) | types: contact-form, featured-collection, main-page, map, rich-text, slideshow, text-columns | has `main-*`: True
- `templates/page.cat-2.json` — sections: 4 (order: 4) | types: featured-collections, main-page, rich-text | has `main-*`: True
- `templates/page.cat.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.contact.json` — sections: 3 (order: 3) | types: contact-form, main-page, rich-text | has `main-*`: True
- `templates/page.dog-2.json` — sections: 5 (order: 5) | types: featured-collections, main-page, rich-text | has `main-*`: True
- `templates/page.dog-collection-list.json` — sections: 5 (order: 5) | types: featured-collections, main-page, rich-text | has `main-*`: True
- `templates/page.faq.json` — sections: 2 (order: 2) | types: faq, main-page | has `main-*`: True
- `templates/page.full-width.json` — sections: 1 (order: 1) | types: main-page-full-width | has `main-*`: True
- `templates/page.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.legal-notice.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.liste-der-katzensammlunge.json` — sections: 4 (order: 4) | types: featured-collections, main-page, rich-text | has `main-*`: True
- `templates/page.privacy-policy-2.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.privacy-policy.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.return-and-refund-policy.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.shipping-policy.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/page.terms-of-service.json` — sections: 1 (order: 1) | types: main-page | has `main-*`: True
- `templates/password.json` — sections: 3 (order: 3) | types: newsletter, password-header, slideshow | has `main-*`: False
- `templates/product.brand-story.json` — sections: 8 (order: 8) | types: background-image-text, collection-return, main-product, product-full-width, product-recommendations, testimonials, text-and-image | has `main-*`: True
- `templates/product.gift-card.json` — sections: 2 (order: 2) | types: main-product, product-full-width | has `main-*`: True
- `templates/product.json` — sections: 10 (order: 10) | types: apps, background-image-text, collection-return, main-product, newsletter, product-full-width, product-recommendations, testimonials, text-and-image | has `main-*`: True
- `templates/product.modal.json` — sections: 1 (order: 1) | types: main-product | has `main-*`: True
- `templates/product.preorder.json` — sections: 4 (order: 4) | types: collection-return, main-product, product-full-width, product-recommendations | has `main-*`: True
- `templates/product.product-landing.json` — sections: 10 (order: 10) | types: collection-return, faq, hero-video, main-product, product-full-width, product-recommendations, slideshow, testimonials, text-and-image | has `main-*`: True
- `templates/search.json` — sections: 1 (order: 1) | types: main-search | has `main-*`: True

## Layout / Head Meta (theme.liquid)

- has_title_tag: False
- has_meta_desc: True
- has_og: False
- has_twitter: False
- has_canonical: True
- has_preconnect: True
- has_preload_font: False
- has_jsonld: False
- uses_content_for_header: True
- uses_content_for_layout: True
- loads_google_fonts: False
- contains_inline_css: False
- External scripts: 1
  - https://api.archetypethemes.co/design-mode.js
- External links: 6
  - https://cdn.shopify.com
  - https://fonts.shopifycdn.com
  - https://productreviews.shopifycdn.com
  - https://ajax.googleapis.com
  - https://maps.googleapis.com
  - https://maps.gstatic.com

## Script Loading

- total_scripts: 6
- defer_count: 4
- async_count: 0
- module_count: 0

## Image Implementation (sections/snippets)

- `snippets/image-element.liquid` — img tags: 2 | lazy: 0 | srcset: 2 | sizes: 2 | decoding=async: 0 | width/height: 2/2
- `sections/max-collection-list.liquid` — img tags: 1 | lazy: 1 | srcset: 0 | sizes: 0 | decoding=async: 0 | width/height: 1/1

## JSON-LD / Structured Data Files

- sections/article-template.liquid
- sections/faq.liquid
- sections/main-collection.liquid
- snippets/product-template-variables.liquid

## Breadcrumb & Review Schema Hints

- Breadcrumb-related files:
  - sections/article-template.liquid
  - sections/blog-template.liquid
  - sections/list-collections-template.liquid
  - sections/main-cart.liquid
  - sections/main-collection.liquid
  - sections/main-search.liquid
  - snippets/breadcrumbs.liquid
  - snippets/product-template.liquid
- Review/Rating-related files:
  - sections/collection-return.liquid
  - sections/testimonials.liquid
  - snippets/collection-grid-item.liquid
  - snippets/image-element.liquid
  - snippets/media.liquid
  - snippets/product-grid-item.liquid
  - snippets/product-images.liquid
  - snippets/product-template-variables.liquid

## Actionable Suggestions (High Impact)

- Preload the primary webfont (`<link rel="preload" as="font" crossorigin href="...woff2">`) to reduce FOIT/FOUT.
- Convert blocking scripts to `defer` where safe; keep critical inline minimal.
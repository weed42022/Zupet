#!/usr/bin/env python3
import argparse, re, sys
from pathlib import Path

def read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

def write_backup(p: Path):
    if p.exists():
        bak = p.with_suffix(p.suffix + ".bak")
        bak.write_text(p.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")

def write_text(p: Path, content: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")

def ensure_preconnect_preload(theme_liquid: Path, log):
    html = read(theme_liquid)
    if not html:
        log.append("WARN theme.liquid not found")
        return
    head_idx = html.lower().find("<head")
    if head_idx == -1:
        log.append("WARN <head> not found")
        return
    # Preconnect
    if "cdn.shopify.com" not in html:
        insert = '\n<link rel="preconnect" href="https://cdn.shopify.com" crossorigin>\n'
        html = html.replace("</head>", insert + "</head>")
        log.append("ADD preconnect cdn.shopify.com")
    # Preload font (only if a woff2 asset URL is present in theme settings; heuristic skipped)
    # Keep as instruction only; safer to avoid broken hrefs automatically.
    write_backup(theme_liquid)
    write_text(theme_liquid, html)

def defer_scripts(theme_liquid: Path, log):
    html = read(theme_liquid)
    if not html: 
        return
    def repl(m):
        tag = m.group(0)
        if "src=" not in tag.lower():  # inline script, skip
            return tag
        if "defer" in tag.lower() or "type=\"module\"" in tag.lower():
            return tag
        # add defer before closing '>'
        tag2 = re.sub(r">\s*$", " defer>", tag)
        log.append("DEFER " + tag.strip()[:80])
        return tag2
    new = re.sub(r"<script\b[^>]*>", repl, html, flags=re.IGNORECASE)
    if new != html:
        write_backup(theme_liquid)
        write_text(theme_liquid, new)

def ensure_snippet(snippets_dir: Path, name: str, content: str, log):
    p = snippets_dir / f"{name}.liquid"
    if p.exists():
        log.append(f"SKIP snippet exists: {name}")
        return
    write_text(p, content)
    log.append(f"ADD snippet: {name}")

def inject_render_in_file(path: Path, render_code: str, anchor_regex: str, log, after=True):
    txt = read(path)
    if not txt:
        return False
    if render_code in txt:
        log.append(f"SKIP already present in {path.name}")
        return True
    anchor = re.search(anchor_regex, txt, flags=re.IGNORECASE)
    if not anchor:
        return False
    insert_at = anchor.end() if after else anchor.start()
    new = txt[:insert_at] + "\n" + render_code + "\n" + txt[insert_at:]
    write_backup(path)
    write_text(path, new)
    log.append(f"INJECT into {path.name}: {render_code.strip()[:60]}")
    return True

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--theme-dir", required=True, help="Path to extracted theme folder")
    args = ap.parse_args()
    theme = Path(args.theme_dir)

    layout = theme / "layout" / "theme.liquid"
    sections = theme / "sections"
    snippets = theme / "snippets"
    templates = theme / "templates"

    log = []

    # 1) head preconnect + 2) defer scripts
    ensure_preconnect_preload(layout, log)
    defer_scripts(layout, log)

    # 3) ensure snippets
    ensure_snippet(snippets, "product-schema", PRODUCT_SCHEMA, log)
    ensure_snippet(snippets, "breadcrumbs-schema", BREADCRUMBS_SCHEMA, log)

    # 4) inject renders
    main_product = sections / "main-product.liquid"
    inject_render_in_file(main_product, "{% render 'product-schema' %}", r"</section>|</div>\s*</section>", log, after=False)

    # Breadcrumbs on product & collection templates (JSON-based OS2.0 makes this tricky).
    # Heuristic: inject into main-collection.liquid if exists, else layout before </body>.
    main_collection = sections / "main-collection.liquid"
    ok = inject_render_in_file(main_collection, "{% render 'breadcrumbs-schema' %}", r"</section>|</div>\s*</section>", log, after=False)
    if not ok:
        inject_render_in_file(layout, "{% render 'breadcrumbs-schema' %}", r"</body>", log, after=False)

    # Write log
    write_text(theme / "zupet_auto_patch.log", "\n".join(log))
    print("Done. Changes:\n" + "\n".join(log))

# Embedded snippet contents
PRODUCT_SCHEMA = r\"\"\"{% comment %} Auto-inserted Product JSON-LD {% endcomment %}
{% if product %}
<script type=\"application/ld+json\">
{
  \"@context\": \"https://schema.org\",
  \"@type\": \"Product\",
  \"name\": {{ product.title | json }},
  \"image\": [{% for m in product.media limit:6 %}{{ m | image_url: width: 1200 | json }}{% unless forloop.last %}, {% endunless %}{% endfor %}],
  \"sku\": {{ product.selected_or_first_available_variant.sku | json }},
  {% if product.vendor %}\"brand\": {\"@type\":\"Brand\",\"name\": {{ product.vendor | json }} },{% endif %}
  {% if product.selected_or_first_available_variant.barcode %}\"gtin13\": {{ product.selected_or_first_available_variant.barcode | json }},{% endif %}
  \"offers\": {
    \"@type\": \"Offer\",
    \"priceCurrency\": {{ shop.currency | json }},
    \"price\": {{ product.selected_or_first_available_variant.price | money_without_currency | replace:',','.' | json }},
    \"availability\": \"https://schema.org/{% if product.selected_or_first_available_variant.available %}InStock{% else %}OutOfStock{% endif %}\"
  }
  {% if product.metafields.reviews.rating.value %},
  \"aggregateRating\": {
    \"@type\":\"AggregateRating\",
    \"ratingValue\": {{ product.metafields.reviews.rating.value | json }},
    \"reviewCount\": {{ product.metafields.reviews.rating.count | default: 0 | json }}
  }
  {% endif %}
}
</script>
{% endif %}
\"\"\"
BREADCRUMBS_SCHEMA = r\"\"\"{% comment %} Auto-inserted BreadcrumbList JSON-LD {% endcomment %}
{% if template contains 'product' or template contains 'collection' %}
<script type=\"application/ld+json\">
{
 \"@context\":\"https://schema.org\",
 \"@type\":\"BreadcrumbList\",
 \"itemListElement\":[
  {\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"{{ routes.root_url | absolute_url }}\"}
  {% if collection %},
  {\"@type\":\"ListItem\",\"position\":2,\"name\": {{ collection.title | json }},\"item\":\"{{ collection.url | absolute_url }}\"}
  {% endif %}
  {% if product %},
  {\"@type\":\"ListItem\",\"position\":{% if collection %}3{% else %}2{% endif %},\"name\": {{ product.title | json }},\"item\":\"{{ product.url | absolute_url }}\"}{% endif %}
 ]
}
</script>
{% endif %}
\"\"\"

if __name__ == "__main__":
    main()
